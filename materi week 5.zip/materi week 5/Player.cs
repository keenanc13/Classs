﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace materi_week_5
{
    internal class Player
    {
        private string playerName;
        private string playerNum;
        private string playerPos;

        //Constructor -- dipanggil setiap classnya dibuat
        public Player(string _playerName,string _playerNum, string _playerPos)
        {
            playerName = _playerName;
            playerNum = _playerNum;
            playerPos = _playerPos;
            
        }

        //Getter
        public string getPlayerName() { return playerName; }
        public string getPlayerNum() {  return playerNum; }
        public string getPlayerPos() {  return playerPos; }

        //Setter
        public void setPlayerName(string playerName) { this.playerName = playerName; }
        public void setPlayerNum(string playerNum) { this.playerNum = playerNum; }
        public void setPlayerPos(string playerPos) {  this.playerPos = playerPos; }
    }
}
