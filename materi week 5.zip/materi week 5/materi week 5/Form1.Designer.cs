﻿namespace materi_week_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_s = new System.Windows.Forms.Button();
            this.tb_Jumlah = new System.Windows.Forms.TextBox();
            this.tb_Remove = new System.Windows.Forms.TextBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_s
            // 
            this.btn_s.Location = new System.Drawing.Point(1682, 135);
            this.btn_s.Name = "btn_s";
            this.btn_s.Size = new System.Drawing.Size(194, 116);
            this.btn_s.TabIndex = 0;
            this.btn_s.Text = "Add";
            this.btn_s.UseVisualStyleBackColor = true;
            this.btn_s.Click += new System.EventHandler(this.btn_s_Click);
            // 
            // tb_Jumlah
            // 
            this.tb_Jumlah.Location = new System.Drawing.Point(1695, 69);
            this.tb_Jumlah.Name = "tb_Jumlah";
            this.tb_Jumlah.Size = new System.Drawing.Size(100, 31);
            this.tb_Jumlah.TabIndex = 1;
            // 
            // tb_Remove
            // 
            this.tb_Remove.Location = new System.Drawing.Point(1682, 300);
            this.tb_Remove.Name = "tb_Remove";
            this.tb_Remove.Size = new System.Drawing.Size(100, 31);
            this.tb_Remove.TabIndex = 2;
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(1682, 371);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(194, 116);
            this.btn_Remove.TabIndex = 3;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2146, 1291);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.tb_Remove);
            this.Controls.Add(this.tb_Jumlah);
            this.Controls.Add(this.btn_s);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_s;
        private System.Windows.Forms.TextBox tb_Jumlah;
        private System.Windows.Forms.TextBox tb_Remove;
        private System.Windows.Forms.Button btn_Remove;
    }
}

