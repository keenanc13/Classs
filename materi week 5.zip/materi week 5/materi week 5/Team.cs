﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace materi_week_5
{
    internal class Team
    {
        private string teamName;
        private string teamCountry;
        private string teamCity;
        private List<Player> playerlist;
        public string phoneNumber;
        private string privatephoneNumber;

        //Constructor
        public Team(string teamName,string teamCountry, string teamCity,List<Player> playerList)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
            this.playerlist = playerList;
        }

        //Getter
        public string getTeamName() { return teamName; }
        public string getTeamCountry() {  return teamCountry; }
        public string getTeamCity() {  return teamCity; }
        public List<Player> getPlayerlist() {  return playerlist; }

        //Setter
            
        public void setTeamName(string _teamName) {  teamName = _teamName; }
        public void setTeamCountry(string _teamCountry) {  teamCountry = _teamCountry; }
        public void setTeamCity(string _teamCity) { teamCity = _teamCity; }
        public void setTeamPlayer(List<Player> _playerList) {  playerlist = _playerList; }
        public void setPrivatePhone (string _phone)
        {
            if (_phone.Contains("a"))
            {
                MessageBox.Show("Error");
            }
            else
            {
                privatephoneNumber = _phone;
            }
        }

        public void AddPlayer(Player player)
        {
            bool kembar = false;
            foreach (Player p in playerlist)
            {
                if(p.getPlayerNum() == player.getPlayerNum())
                {
                    kembar = true;
                    break;
                }
            }
            if (kembar)
            {
                MessageBox.Show("Ada player dengan nomor sama");

            }
            else
            {
                playerlist.Add(player);
            }
            
        }
    }
}
