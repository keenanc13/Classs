﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace materi_week_5
{
    public partial class Form1 : Form
    {
        List <Button> butt;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            butt = new List<Button>();
        }

        private void btn_a_Click(object sender, EventArgs e)
        {
            Button sebuahTombol = (Button)sender;
            sebuahTombol.Text = "Aku bingung";
            MessageBox.Show(sebuahTombol.Tag.ToString());
        }

            private void btn_s_Click(object sender, EventArgs e)
        {
            if (butt.Count == 0)
            {
                for (int i = 1; i <= Convert.ToInt16(tb_Jumlah.Text); i++)
                {
                    Button btn = new Button();
                    btn.Name = "Yuhuke-" + i;
                    btn.Text = "button" + i;
                    btn.Tag = "Button ke-" + i;
                    btn.Size = new Size(150, 30);
                    btn.Location = new Point(30, 30 * i);
                    btn.BackColor = Color.Cyan;
                    btn.ForeColor = Color.Red;
                    btn.Click += new EventHandler(btn_a_Click);
                    this.Controls.Add(btn);
                    butt.Add(btn);
                }
            }
            else
            {
                for (int i = 0; i < butt.Count; i++)
                {
                    this.Controls.Remove(butt[i]);
                }
                for (int i = 1; i <= Convert.ToInt16(tb_Jumlah.Text); i++)
                {
                    Button btn = new Button();
                    btn.Name = "Yuhuke-" + i;
                    btn.Text = "button" + i;
                    btn.Tag = "Button ke-" + i;
                    btn.Size = new Size(150, 30);
                    btn.Location = new Point(30, 30 * i);
                    btn.BackColor = Color.Cyan;
                    btn.ForeColor = Color.Red;
                    btn.Click += new EventHandler(btn_a_Click);
                    this.Controls.Add(btn);
                    butt.Add(btn);
                }
            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(butt[Convert.ToInt16(tb_Remove.Text) -1]);
        }
    }
}
