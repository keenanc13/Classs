﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace materi_week_5
{
    public partial class Form1 : Form
    {
        List<Team> teams;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           teams = new List<Team>();
            List<Player> players = new List<Player>
            {
                new Player("Edwin","01","GK"),
                new Player("Christian","02","DF"),
                new Player("Keenan","03", "FW"),
            };
            teams.Add(new Team("UC Ceria","Indonesia","Surabaya",players));
            players = new List<Player>
            {
                new Player("Edward","05", "GK"),
                new Player("Jevon","10", "DF"),
                new Player("Kevin","15", "FW"),
                new Player("Steve","20", "MF")
            };
            teams.Add(new Team("AD Keren", "Indonesia", "Surabaya", players));
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {

            foreach(Team t in teams)
            {
                t.AddPlayer(new Player("Edwin", "01", "GK"));
                string output = t.getTeamName() + " is a " + t.getTeamCountry() + " team with "  + 
                    t.getPlayerlist().Count().ToString() + " players.";
                MessageBox.Show(output);
            }
        }
    }
}
