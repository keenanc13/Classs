﻿using System;
using System.Data;
using System.Windows.Forms;

namespace week5
{
    public partial class Form1 : Form
    {
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("ID Tim");
            dt.Columns.Add("Nama Tim");
            dt.Columns.Add("Stadium");
            dt.Columns.Add("Kapasitas");
            dt.Columns.Add("Kota");
            dt.Columns.Add("Nama Manager");
            Gridview_data.DataSource = dt;
            tb_ID.Enabled = false;

        }

        private void btn_Input_Click(object sender, EventArgs e)
        {
            bool tim = false;
            bool stadium = false;
            bool manager = false;
            if (tb_Tim.Text == "" || tb_Stadium.Text == "" || tb_Kapasitas.Text == "" || tb_Kota.Text == "" || tb_Manager.Text == "")
            {
                MessageBox.Show("Please fill all the fields first", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr["Nama Tim"].ToString() == tb_Tim.Text)
                    {
                        tim = true;
                    }
                    else if (dr["Stadium"].ToString() == tb_Stadium.Text)
                    {
                        stadium = true;
                    }
                    else if (dr["Nama Manager"].ToString() == tb_Manager.Text)
                    {
                        manager = true;
                    }
                }
                if (tim == true)
                {
                    MessageBox.Show("Nama Tim tidak boleh sama", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (stadium == true)
                {
                    MessageBox.Show("Nama Stadium tidak boleh sama", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (manager == true)
                {
                    MessageBox.Show("Nama Manager tidak boleh sama", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    dt.Rows.Add(tb_ID.Text,tb_Tim.Text, tb_Stadium.Text, tb_Kapasitas.Text, tb_Kota.Text, tb_Manager.Text);
                }
                tb_ID.Text = "";
                tb_Tim.Text = "";
                tb_Stadium.Text = "";
                tb_Kapasitas.Text = "";
                tb_Kota.Text = "";
                tb_Manager.Text = "";
            }
        }

        private void tb_Tim_TextChanged(object sender, EventArgs e)
        {
            int count = 0;
            string id="";
            tb_ID.Text = "";
            
            if (tb_Tim.Text != "")
            {
                id += tb_Tim.Text[0].ToString().ToUpper();

            }

            int angka = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string idTeam = dt.Rows[i]["ID Tim"].ToString();
                if (idTeam[0].ToString() == id)
                {
                    count++;
                }
            }
            if (count < 10)
            {
                angka = count + 1;
                id += "0" + angka.ToString();
            }
            else
            {
                id += (count + 1).ToString();
            }

            if (tb_Tim.Text != "")
            {
                tb_ID.Text = id;
            }

        }
    }
}
