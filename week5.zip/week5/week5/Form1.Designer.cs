﻿namespace week5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.tb_Tim = new System.Windows.Forms.TextBox();
            this.tb_Stadium = new System.Windows.Forms.TextBox();
            this.tb_Kapasitas = new System.Windows.Forms.TextBox();
            this.tb_Kota = new System.Windows.Forms.TextBox();
            this.tb_Manager = new System.Windows.Forms.TextBox();
            this.btn_Input = new System.Windows.Forms.Button();
            this.Gridview_data = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview_data)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_ID
            // 
            this.lb_ID.AutoSize = true;
            this.lb_ID.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lb_ID.Location = new System.Drawing.Point(157, 100);
            this.lb_ID.Name = "lb_ID";
            this.lb_ID.Size = new System.Drawing.Size(73, 25);
            this.lb_ID.TabIndex = 0;
            this.lb_ID.Text = "Tim ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(157, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nama Tim";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(157, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nama Stadium";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(157, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Kapasitas";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(157, 319);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Kota";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(157, 376);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Nama Manager";
            // 
            // tb_ID
            // 
            this.tb_ID.Location = new System.Drawing.Point(363, 93);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(211, 31);
            this.tb_ID.TabIndex = 6;
            // 
            // tb_Tim
            // 
            this.tb_Tim.Location = new System.Drawing.Point(363, 142);
            this.tb_Tim.Name = "tb_Tim";
            this.tb_Tim.Size = new System.Drawing.Size(211, 31);
            this.tb_Tim.TabIndex = 7;
            this.tb_Tim.TextChanged += new System.EventHandler(this.tb_Tim_TextChanged);
            // 
            // tb_Stadium
            // 
            this.tb_Stadium.Location = new System.Drawing.Point(363, 199);
            this.tb_Stadium.Name = "tb_Stadium";
            this.tb_Stadium.Size = new System.Drawing.Size(211, 31);
            this.tb_Stadium.TabIndex = 8;
            // 
            // tb_Kapasitas
            // 
            this.tb_Kapasitas.Location = new System.Drawing.Point(363, 260);
            this.tb_Kapasitas.Name = "tb_Kapasitas";
            this.tb_Kapasitas.Size = new System.Drawing.Size(211, 31);
            this.tb_Kapasitas.TabIndex = 9;
            // 
            // tb_Kota
            // 
            this.tb_Kota.Location = new System.Drawing.Point(363, 316);
            this.tb_Kota.Name = "tb_Kota";
            this.tb_Kota.Size = new System.Drawing.Size(211, 31);
            this.tb_Kota.TabIndex = 10;
            // 
            // tb_Manager
            // 
            this.tb_Manager.Location = new System.Drawing.Point(363, 376);
            this.tb_Manager.Name = "tb_Manager";
            this.tb_Manager.Size = new System.Drawing.Size(211, 31);
            this.tb_Manager.TabIndex = 11;
            // 
            // btn_Input
            // 
            this.btn_Input.Location = new System.Drawing.Point(387, 430);
            this.btn_Input.Name = "btn_Input";
            this.btn_Input.Size = new System.Drawing.Size(92, 42);
            this.btn_Input.TabIndex = 12;
            this.btn_Input.Text = "Input";
            this.btn_Input.UseVisualStyleBackColor = true;
            this.btn_Input.Click += new System.EventHandler(this.btn_Input_Click);
            // 
            // Gridview_data
            // 
            this.Gridview_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gridview_data.Location = new System.Drawing.Point(141, 529);
            this.Gridview_data.Name = "Gridview_data";
            this.Gridview_data.RowHeadersWidth = 82;
            this.Gridview_data.RowTemplate.Height = 33;
            this.Gridview_data.Size = new System.Drawing.Size(1405, 392);
            this.Gridview_data.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2150, 1216);
            this.Controls.Add(this.Gridview_data);
            this.Controls.Add(this.btn_Input);
            this.Controls.Add(this.tb_Manager);
            this.Controls.Add(this.tb_Kota);
            this.Controls.Add(this.tb_Kapasitas);
            this.Controls.Add(this.tb_Stadium);
            this.Controls.Add(this.tb_Tim);
            this.Controls.Add(this.tb_ID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_ID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Gridview_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_ID;
        private System.Windows.Forms.TextBox tb_Tim;
        private System.Windows.Forms.TextBox tb_Stadium;
        private System.Windows.Forms.TextBox tb_Kapasitas;
        private System.Windows.Forms.TextBox tb_Kota;
        private System.Windows.Forms.TextBox tb_Manager;
        private System.Windows.Forms.Button btn_Input;
        private System.Windows.Forms.DataGridView Gridview_data;
    }
}

